﻿// =====================================================================
//  This file is part of the Microsoft Dynamics CRM SDK code samples.
//
//  Copyright (C) Microsoft Corporation.  All rights reserved.
//
//  This source code is intended only as a supplement to Microsoft
//  Development Tools and/or on-line documentation.  See these other
//  materials for detailed information regarding Microsoft code samples.
//
//  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
//  PARTICULAR PURPOSE.
// =====================================================================

using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Data;
using System.ComponentModel;
using USDCTICallTester.Utility;
using System.Net;
using System.Collections.Specialized;
using System.IO;
using Microsoft.Win32;
using Newtonsoft.Json;

namespace USDCTICallTester
{
	public class CallDataViewModel : INotifyPropertyChanged
	{

        /// <remarks/>
        private string _Ani;
        /// <remarks/>
        private string _Dnis;
        /// <remarks/>
        private string _type;
        /// <remarks/>
        private List<CallDataItem> _calldataItems;
        /// <remarks/>
        private string _usdLocalAddress;
        private string SettingsFileName = "ctiSettings.dat";

        /// <summary>
        /// Gets or Sets UsdLocalAddress
        /// </summary>
        public string UsdLocalAddress { get { return _usdLocalAddress; } set { SetProperty(ref _usdLocalAddress, value, "UsdLocalAddress"); } }
        /// <summary>
        /// Gets or Sets CallDataItems
        /// </summary>
        public List<CallDataItem> CallDataItems { get { return _calldataItems; } set { SetProperty(ref _calldataItems, value, "CallDataItems"); } }

        /// <summary>
        /// Gets or Sets CallType
        /// </summary>
        public string CallType { get { return _type; } set { SetProperty(ref _type, value, "CallType"); } }
        /// <summary>
        /// Gets or Sets Dnis
        /// </summary>
        public string Dnis { get { return _Dnis; } set { SetProperty(ref _Dnis, value, "Dnis"); } }
        /// <summary>
        /// Gets or Sets Ani
        /// </summary>
        public string Ani { get { return _Ani; } set { SetProperty(ref _Ani, value, "Ani"); } }

        public System.Windows.Input.ICommand SendToUSD { get; internal set; }

        public System.Windows.Input.ICommand SaveSettings { get; internal set; }
        public System.Windows.Input.ICommand LoadSettings { get; internal set; }

        public event EventHandler PreSave = null; 

		public CallDataViewModel()
		{
            CallType = "VOIP";
            Ani = "555-5551";
            Dnis = "703-555-1234";
            UsdLocalAddress = "http://localhost:5000";
            CallDataItems = new List<CallDataItem>();
            SendToUSD = new RelayCommand(param => SendRequestToUSD());
            LoadSettings = new RelayCommand(param => LoadSimSettings());
            SaveSettings = new RelayCommand(param => SaveSimSettings());

		}

        /// <summary>
        /// Sends the request to CRM. 
        /// </summary>
        private void SendRequestToUSD()
        {
           
            using (var wb = new WebClient())
            {
                var data = new NameValueCollection();
                data["ani"] = Ani;
                data["dnis"] = Dnis;
                data["type"] = CallType;

                foreach (var itm in CallDataItems)
                {
                    if (!string.IsNullOrEmpty(itm.Key))
                        data.Add(itm.Key, itm.Value); 
                }

                try
                {
                    if ( Uri.IsWellFormedUriString(UsdLocalAddress, UriKind.RelativeOrAbsolute))
                        wb.UploadValues(new Uri(UsdLocalAddress), "POST", data);
                    else
                        System.Windows.MessageBox.Show("Invalid URL format", "Failed to send call event"); 
                }
                catch (System.Exception ex)
                {
                    System.Windows.MessageBox.Show(ex.Message, "Failed to send call event"); 
                }
            }

        }

        private void SaveSimSettings()
        {
            if (PreSave != null)
                PreSave(this, null);

            FileInfo defaultFileInfo = new FileInfo(SettingsFileName);

            string outfile = JsonConvert.SerializeObject(this, Formatting.None);

            SaveFileDialog SaveFileTooDlg = new SaveFileDialog();
            SaveFileTooDlg.DefaultExt = ".dat";
            SaveFileTooDlg.FileName = defaultFileInfo.Name;
            SaveFileTooDlg.AddExtension = true;
            SaveFileTooDlg.InitialDirectory = defaultFileInfo.DirectoryName;
            SaveFileTooDlg.Title = "Save CTI Sim Settings File";
            SaveFileTooDlg.Filter = "CTI Sim Setting File (*.dat)|*.dat;";
            var result = SaveFileTooDlg.ShowDialog();
            if (result.Value)
            {
                // Get file path to store too. 
                SaveFileToDisk(SaveFileTooDlg.FileName, outfile);
            }

        }

        private void LoadSimSettings()
        {
            FileInfo defaultFileInfo = new FileInfo(SettingsFileName);
            OpenFileDialog OpenFileFromDlg = new OpenFileDialog();
            OpenFileFromDlg.Title = "Load CTI Sim Settings File";
            OpenFileFromDlg.Filter = "CTI Sim Setting File (*.dat)|*.dat;";
            OpenFileFromDlg.InitialDirectory = defaultFileInfo.DirectoryName;
            OpenFileFromDlg.DefaultExt = ".dat";

            var result = OpenFileFromDlg.ShowDialog();
            if (result.Value)
            {
                string infile = ReadFileFromDisk(OpenFileFromDlg.FileName);
                if (!string.IsNullOrEmpty(infile))
                {
                    var locaSettingsInfo = JsonConvert.DeserializeObject<CallDataViewModel>(infile);
                    if (locaSettingsInfo != null)
                    {
                        Ani = locaSettingsInfo.Ani;
                        Dnis = locaSettingsInfo.Dnis;
                        CallType = locaSettingsInfo.CallType;
                        UsdLocalAddress = locaSettingsInfo.UsdLocalAddress;
                        CallDataItems = locaSettingsInfo.CallDataItems; 
                        //settingsInfo = locaSettingsInfo;
                        //ConfigureGameSettings();
                    }
                }
            }

        }


        /// <summary>
        /// Saves a file to disk. 
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        public static bool SaveFileToDisk(string fileName, string data)
        {
            try
            {
                FileInfo fiIn = new FileInfo(fileName);
                if (File.Exists(fileName))
                    File.Delete(fileName);

                using (StreamWriter sw = new StreamWriter(fileName))
                {
                    sw.Write(data);
                    sw.Flush();
                    sw.Close();
                }

                return true;
            }
            catch (DirectoryNotFoundException dEx)
            {
               // App.DiagLog.Log("SaveProfileToDisk", TraceEventType.Verbose, dEx);
            }
            catch (IOException iOEx)
            {
                //App.DiagLog.Log("SaveProfileToDisk", TraceEventType.Verbose, iOEx);
            }
            catch (Exception ex)
            {
                //App.DiagLog.Log("SaveProfileToDisk", TraceEventType.Verbose, ex);
            }
            return false;
        }

        /// <summary>
        /// This reads the File from disk 
        /// </summary>
        /// <param name="fileName">file path</param>
        /// <returns>Read File</returns>
        public static string ReadFileFromDisk(string fileName)
        {
            try
            {
                FileInfo targetFile = new FileInfo(fileName);

                // Read the complete file 
                StringBuilder sbFileData = new StringBuilder();
                using (StreamReader flReader = new StreamReader(targetFile.FullName))
                {
                    sbFileData.Append(flReader.ReadToEnd());
                }
             
                return sbFileData.ToString();
            }
            catch (Exception ex)
            {
                return string.Empty;
            }

        }


        #region INotifyPropertyChanged

        /// <remarks/>
        private void SetProperty<T>(ref T field, T value, string name)
        {
            if (!EqualityComparer<T>.Default.Equals(field, value))
            {
                field = value;
                var hander = PropertyChanged;
                if (hander != null)
                    hander(this, new PropertyChangedEventArgs(name));
            }
        }

        /// <summary>
        /// Default Event Hook for INotifyPropertyChanged
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <remarks/>
        private void NotifyPropertyChanged(String info)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(info));
            }
        }
        #endregion
    
	}
}

/// <summary>
/// Update CallDataItem description here. 
/// </summary>
public sealed class CallDataItem : INotifyPropertyChanged
{
    /// <remarks/>
    private string _keyName;
    /// <remarks/>
    private string _valueName;

    /// <summary>
    /// Gets or Sets Value
    /// </summary>
    public string Value { get { return _valueName; } set { SetProperty(ref _valueName, value, "Value"); } }

    /// <summary>
    /// Gets or Sets Key
    /// </summary>
    public string Key { get { return _keyName; } set { SetProperty(ref _keyName, value, "Key"); } }


    #region INotifyPropertyChanged

    /// <remarks/>
    private void SetProperty<T>(ref T field, T value, string name)
    {
        if (!EqualityComparer<T>.Default.Equals(field, value))
        {
            field = value;
            var hander = PropertyChanged;
            if (hander != null)
                hander(this, new PropertyChangedEventArgs(name));
        }
    }

    /// <summary>
    /// Default Event Hook for INotifyPropertyChanged
    /// </summary>
    public event PropertyChangedEventHandler PropertyChanged;

    /// <remarks/>
    private void NotifyPropertyChanged(String info)
    {
        if (PropertyChanged != null)
        {
            PropertyChanged(this, new PropertyChangedEventArgs(info));
        }
    }
    #endregion
    
}


